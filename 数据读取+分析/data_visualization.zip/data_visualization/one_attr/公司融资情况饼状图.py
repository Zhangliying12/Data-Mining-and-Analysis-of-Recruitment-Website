import tool

colors = ['springgreen','yellowgreen','lightskyblue','yellow','peachpuff','seashell','cyan','lightgrey']
tool.drawPie(
    'company_finance',
    tool.finance,
    [20,9],
    "公司融资情况分析饼状图",
    colors
)
