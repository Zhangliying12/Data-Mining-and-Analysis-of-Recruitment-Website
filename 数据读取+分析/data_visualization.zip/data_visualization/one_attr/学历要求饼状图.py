import tool

colors=['springgreen', 'yellowgreen', 'lightskyblue', 'yellow', 'peachpuff']
tool.drawPie('degree',
             tool.degree,
             [15,9],
             "学历要求分布饼状图",
             colors)
