import tool

tool.drawBar('company_name',
             [15,9],
             20,
             90,
             '公司岗位数量（TOP20）',
             '公司名',
             '职位数量(单位：个)',
             "./")
