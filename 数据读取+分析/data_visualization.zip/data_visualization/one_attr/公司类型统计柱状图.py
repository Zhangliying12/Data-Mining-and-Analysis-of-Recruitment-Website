import tool
tool.drawBar('company_type',
             [15,9],
             10,
             45,
             '不同公司类型（TOP10）',
             '公司类型名称',
             '对应数量(单位：个)',
             "dir_name")
