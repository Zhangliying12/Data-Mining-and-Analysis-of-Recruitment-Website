import tool

colors = ['springgreen','lightgrey','lightskyblue','yellow','peachpuff','cyan']
tool.drawPie('company_scale',
             tool.scale,
             [15,9],
             "公司规模统计",
             colors)