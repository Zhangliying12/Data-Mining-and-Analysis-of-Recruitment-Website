import tool

colors = ['yellow','yellowgreen','lightskyblue','springgreen','cyan','peachpuff','seashell'] #每块颜色定义
tool.drawPie('experience',
             tool.exp,
             [15,9],
             "工作经验要求分布饼状图",
             colors)