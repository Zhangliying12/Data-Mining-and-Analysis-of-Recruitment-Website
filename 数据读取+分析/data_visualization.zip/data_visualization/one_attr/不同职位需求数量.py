import tool

tool.drawBar('position',
             [15,9],
             20,
             45,
             '不同职位需求（TOP20）',
             '职位名称',
             '职位数量(单位：个)',
             'dir_name')
