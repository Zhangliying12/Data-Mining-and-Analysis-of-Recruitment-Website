import tool

tool.drawWordCloud('bonus')
